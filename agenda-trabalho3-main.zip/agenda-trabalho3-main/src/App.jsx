import Cabecalho from './Cabecalho'
import Lista from './Lista'

function App() {

  return (
    <div>
      <Cabecalho />
      <Lista />
    </div>
  )
}

export default App
